package com.delish.bite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BiteApplicationTests {

    @Test
    void contextLoads() {
    }

}
