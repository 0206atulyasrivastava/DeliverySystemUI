package com.delish.bite.cotrollers;

import com.delish.bite.dtos.DeliveryOrderDto;
import com.delish.bite.models.DeliveryOrder;
import com.delish.bite.repositories.DeliveryOrderRepo;
import com.delish.bite.service.DeliveryOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/order")
@CrossOrigin(origins = "http://localhost:4200")
public class DeliveryOrderController {

    @Autowired
    DeliveryOrderService deliveryOrderService;

    @Autowired
    DeliveryOrderRepo deliveryOrderRepo;

    @GetMapping
    public List<DeliveryOrderDto> getAllOrders() {
        return deliveryOrderService.getAllOrders();
    }

    @PostMapping
    public DeliveryOrder createDeliveryOrder(@RequestBody DeliveryOrder deliveryOrder) {
        return deliveryOrderService.createNewOrder(deliveryOrder);
    }
}
