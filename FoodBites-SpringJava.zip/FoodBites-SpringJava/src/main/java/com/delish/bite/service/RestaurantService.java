package com.delish.bite.service;

import com.delish.bite.dtos.RestaurantDto;
import com.delish.bite.models.Restaurant;
import com.delish.bite.repositories.RestaurantRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class RestaurantService {

    @Autowired
    RestaurantRepo restaurantRepo;

    public Set<RestaurantDto> getAllRestaurants() {
        List<Restaurant> data = restaurantRepo.findAll();

        Set<RestaurantDto> result = new HashSet<>();

        data.forEach(e -> {
            result.add(new RestaurantDto(e.getRestaurantId(), e.getName(), e.getLocation().getName(), e.getRating(), e.getPriceIndicator(), e.getCostForTwo()));
        });

        return result;
    }
}
