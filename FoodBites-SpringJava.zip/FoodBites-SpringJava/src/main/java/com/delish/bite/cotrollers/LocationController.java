package com.delish.bite.cotrollers;

import com.delish.bite.dtos.FoodDto;
import com.delish.bite.dtos.LocationDto;
import com.delish.bite.dtos.RestaurantDto;
import com.delish.bite.service.LocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("api/location")
public class LocationController {

    @Autowired
    LocationService locationService;

    @GetMapping
    public Set<LocationDto> getAllLocations() {
        return locationService.getAllLocations();
    }

    @GetMapping("/{locationId}")
    public Set<RestaurantDto> getRestaurantsByLocation(@PathVariable Long locationId) {
        return locationService.getAllRestaurantsInLocation(locationId);
    }

    @GetMapping("/{locationId}/menu")
    public List<FoodDto> getMenuByLocation(@PathVariable Long locationId) {
        return locationService.getMenuByLocation(locationId);
    }
}
