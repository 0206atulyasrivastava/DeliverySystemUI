package com.delish.bite.dtos;

import java.util.Set;

public class LocationDto {

    private Long locationId;
    private String locationName;
    private Set<RestaurantDto> restaurants;

    public LocationDto(Long locationId, String locationName) {
        this.locationId = locationId;
        this.locationName = locationName;
    }

    public LocationDto(Long locationId, String locationName, Set<RestaurantDto> restaurants) {
        this.locationId = locationId;
        this.locationName = locationName;
        this.restaurants = restaurants;
    }

    public Long getLocationId() {
        return locationId;
    }

    public void setLocationId(Long locationId) {
        this.locationId = locationId;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public Set<RestaurantDto> getRestaurants() {
        return restaurants;
    }

    public void setRestaurants(Set<RestaurantDto> restaurants) {
        this.restaurants = restaurants;
    }
}
