package com.delish.bite.models;

public enum PriceIndicator {

    HIGH(3),
    MEDIUM(2),
    LOW(1);


    private final int priceIndicatorCode;

    PriceIndicator(int priceIndicatorCode) {
        this.priceIndicatorCode = priceIndicatorCode;
    }

    public int getPriceIndicatorCode() {
        return this.priceIndicatorCode;
    }
}
