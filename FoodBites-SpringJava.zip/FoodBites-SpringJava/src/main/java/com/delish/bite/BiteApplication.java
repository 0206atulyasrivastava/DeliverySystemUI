package com.delish.bite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BiteApplication {

    public static void main(String[] args) {
        SpringApplication.run(BiteApplication.class, args);
    }

}
