package com.delish.bite.repositories;

import com.delish.bite.models.Food;
import com.delish.bite.models.Restaurant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Set;

public interface MenuRepo extends JpaRepository<Food, Long> {

//    @Query("SELECT f FROM Food f WHERE f.restaurant IN (:restaurants)")
    List<Food> findByRestaurantIn(@Param("restaunrantIds") Set<Restaurant> restaurants);
}
