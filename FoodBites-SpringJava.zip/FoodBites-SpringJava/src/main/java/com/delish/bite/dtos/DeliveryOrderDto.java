package com.delish.bite.dtos;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

public class DeliveryOrderDto {

    private Long deliveryOrderId;

    private BigDecimal totalAmount;

    private List<OrderItemsDto> orderItems;

    private Timestamp orderDate;

    public DeliveryOrderDto() {
    }

    public DeliveryOrderDto(BigDecimal totalAmount, List<OrderItemsDto> orderItems, Timestamp orderDate) {
        this.totalAmount = totalAmount;
        this.orderItems = orderItems;
        this.orderDate = orderDate;
    }

    public DeliveryOrderDto(Long deliveryOrderId, BigDecimal totalAmount, List<OrderItemsDto> orderItems, Timestamp orderDate) {
        this.deliveryOrderId = deliveryOrderId;
        this.totalAmount = totalAmount;
        this.orderItems = orderItems;
        this.orderDate = orderDate;
    }

    public Long getDeliveryOrderId() {
        return deliveryOrderId;
    }

    public void setDeliveryOrderId(Long deliveryOrderId) {
        this.deliveryOrderId = deliveryOrderId;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public List<OrderItemsDto> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(List<OrderItemsDto> orderItems) {
        this.orderItems = orderItems;
    }

    public Timestamp getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Timestamp orderDate) {
        this.orderDate = orderDate;
    }
}
