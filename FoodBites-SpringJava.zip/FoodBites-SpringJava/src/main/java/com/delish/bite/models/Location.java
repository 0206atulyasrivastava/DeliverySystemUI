package com.delish.bite.models;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Location {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Long locationId;

    @Column(nullable = false)
    private String name;

    @OneToMany(mappedBy = "location")
    private Set<Restaurant> restaurantsInArea = new HashSet<>();

    public Long getLocationId() {
        return locationId;
    }

    public void setLocationId(Long locationId) {
        this.locationId = locationId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Restaurant> getRestaurantsInArea() {
        return restaurantsInArea;
    }

    public void setRestaurantsInArea(Set<Restaurant> restaurantsInArea) {
        this.restaurantsInArea = restaurantsInArea;
    }
}
