package com.delish.bite.cotrollers;

import com.delish.bite.dtos.FoodDto;
import com.delish.bite.models.Food;
import com.delish.bite.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("api/menu")
@CrossOrigin(origins = "http://localhost:4200")
public class MenuController {

    @Autowired
    MenuService menuService;

    @GetMapping
    public Set<FoodDto> getAllMenu() {
        return menuService.getFullMenu();
    }

    @GetMapping("/{id}")
    public FoodDto getFoodDetails(@PathVariable Long id) {
        return menuService.getFoodDetails(id);
    }
}
