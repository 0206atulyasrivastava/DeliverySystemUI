package com.delish.bite.service;

import com.delish.bite.dtos.FoodDto;
import com.delish.bite.dtos.LocationDto;
import com.delish.bite.dtos.RestaurantDto;
import com.delish.bite.models.Food;
import com.delish.bite.models.Location;
import com.delish.bite.models.Restaurant;
import com.delish.bite.repositories.MenuRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class MenuService {

    @Autowired
    MenuRepo menuRepo;

    public Set<FoodDto> getFullMenu() {
        List<Food> data = menuRepo.findAll();
        Set<FoodDto> result = new HashSet<>();

        data.forEach(e -> {
            result.add(new FoodDto(e.getFoodId(), e.getName(), e.getPrice(), e.getFoodCategory(), e.isVagetarian()));
        });

        return result;
    }

    public FoodDto getFoodDetails(Long id) {
        Optional<Food> data = menuRepo.findById(id);

        if(data.isPresent()) {
            return getFoodDto(data.get());
        }
        return null;
    }

    private FoodDto getFoodDto(Food food) {
        Restaurant r = food.getRestaurant();
        RestaurantDto rest = new RestaurantDto(r.getRestaurantId(), r.getName(), r.getRating(), r.getPriceIndicator());

        Location l = r.getLocation();
        LocationDto loc = new LocationDto(l.getLocationId(), l.getName());
        FoodDto foodDto = new FoodDto(food.getFoodId(), food.getName(), food.getPrice(), food.getFoodCategory(), food.isVagetarian(), rest, loc);

        return foodDto;
    }
}
