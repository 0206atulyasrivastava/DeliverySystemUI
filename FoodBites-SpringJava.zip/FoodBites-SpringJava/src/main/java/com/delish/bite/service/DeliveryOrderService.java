package com.delish.bite.service;

import com.delish.bite.dtos.DeliveryOrderDto;
import com.delish.bite.dtos.OrderItemsDto;
import com.delish.bite.models.DeliveryOrder;
import com.delish.bite.models.OrderItems;
import com.delish.bite.repositories.DeliveryOrderRepo;
import com.delish.bite.repositories.OrderItemRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DeliveryOrderService {

    @Autowired
    DeliveryOrderRepo deliveryOrderRepo;

    @Autowired
    OrderItemRepo orderItemRepo;

    public List<DeliveryOrderDto> getAllOrders() {
        List<DeliveryOrder> data = deliveryOrderRepo.findAll();

        List<DeliveryOrderDto> resultDTO = new ArrayList<>();

        for (DeliveryOrder order : data) {
            List<OrderItems> orderItemsList = order.getOrderItems();
            List<OrderItemsDto> orderItemsDtoList = new ArrayList<>();
            orderItemsList.forEach(e -> {
                orderItemsDtoList.add(new OrderItemsDto(e.getOrderItemId(), e.getItemName(), e.getQuantity(), e.getPrice(), e.getTotal()));
            });
            resultDTO.add(new DeliveryOrderDto(order.getDeliveryOrderId(), order.getTotalAmount(), orderItemsDtoList, order.getOrderDate()));
        }

        return resultDTO;
    }

    public DeliveryOrder createNewOrder(DeliveryOrder deliveryOrder) {
        List<OrderItems> itemsList = deliveryOrder.getOrderItems();
        DeliveryOrder dd = deliveryOrderRepo.save(deliveryOrder);
        for(OrderItems orderItem : itemsList) {
            orderItem.setDeliveryOrder(dd);
            orderItemRepo.save(orderItem);
        }
        return dd;
    }
}
