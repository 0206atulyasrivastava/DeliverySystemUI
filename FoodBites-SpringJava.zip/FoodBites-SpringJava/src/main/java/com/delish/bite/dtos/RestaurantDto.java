package com.delish.bite.dtos;

import com.delish.bite.models.PriceIndicator;

import java.util.List;

public class RestaurantDto {

    private Long restaurantId;

    private String restaurantName;

    private String location;

    private Double rating;

    private PriceIndicator priceIndicator;

    private Integer costForTwo;

    private List<FoodDto> menu;

    public RestaurantDto(Long restaurantId, String restaurantName, Double rating, PriceIndicator priceIndicator) {
        this.restaurantId = restaurantId;
        this.restaurantName = restaurantName;
        this.rating = rating;
        this.priceIndicator = priceIndicator;
    }

    public RestaurantDto(Long restaurantId, String restaurantName, String location, Double rating, PriceIndicator priceIndicator, Integer costForTwo, List<FoodDto> menu) {
        this.restaurantId = restaurantId;
        this.restaurantName = restaurantName;
        this.location = location;
        this.rating = rating;
        this.priceIndicator = priceIndicator;
        this.costForTwo = costForTwo;
        this.menu = menu;
    }

    public RestaurantDto(Long restaurantId, String restaurantName, String location, Double rating, PriceIndicator priceIndicator, Integer costForTwo) {
        this.restaurantId = restaurantId;
        this.restaurantName = restaurantName;
        this.location = location;
        this.rating = rating;
        this.priceIndicator = priceIndicator;
        this.costForTwo = costForTwo;
    }

    public Long getRestaurantId() {
        return restaurantId;
    }

    public void setRestaurantId(Long restaurantId) {
        this.restaurantId = restaurantId;
    }

    public String getRestaurantName() {
        return restaurantName;
    }

    public void setRestaurantName(String restaurantName) {
        this.restaurantName = restaurantName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public PriceIndicator getPriceIndicator() {
        return priceIndicator;
    }

    public void setPriceIndicator(PriceIndicator priceIndicator) {
        this.priceIndicator = priceIndicator;
    }

    public Integer getCostForTwo() {
        return costForTwo;
    }

    public void setCostForTwo(Integer costForTwo) {
        this.costForTwo = costForTwo;
    }

    public List<FoodDto> getMenu() {
        return menu;
    }

    public void setMenu(List<FoodDto> menu) {
        this.menu = menu;
    }
}
