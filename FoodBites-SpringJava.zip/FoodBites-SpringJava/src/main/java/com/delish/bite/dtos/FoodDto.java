package com.delish.bite.dtos;

import java.math.BigDecimal;

public class FoodDto {

    private Long foodId;

    private String name;

    private BigDecimal price;

    private String foodCategory;

    private boolean vagetarian;

    private RestaurantDto restaurant;

    private LocationDto location;

    public FoodDto(Long foodId, String name, BigDecimal price, String foodCategory, boolean vagetarian) {
        this.foodId = foodId;
        this.name = name;
        this.price = price;
        this.foodCategory = foodCategory;
        this.vagetarian = vagetarian;
    }

    public RestaurantDto getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(RestaurantDto restaurant) {
        this.restaurant = restaurant;
    }

    public LocationDto getLocation() {
        return location;
    }

    public void setLocation(LocationDto location) {
        this.location = location;
    }

    public FoodDto(Long foodId, String name, BigDecimal price, String foodCategory, boolean vagetarian, RestaurantDto restaurant, LocationDto location) {
        this.foodId = foodId;
        this.name = name;
        this.price = price;
        this.foodCategory = foodCategory;
        this.vagetarian = vagetarian;
        this.restaurant = restaurant;
        this.location = location;
    }

    public Long getFoodId() {
        return foodId;
    }

    public void setFoodId(Long foodId) {
        this.foodId = foodId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getFoodCategory() {
        return foodCategory;
    }

    public void setFoodCategory(String foodCategory) {
        this.foodCategory = foodCategory;
    }

    public boolean isVagetarian() {
        return vagetarian;
    }

    public void setVagetarian(boolean vagetarian) {
        this.vagetarian = vagetarian;
    }
}
