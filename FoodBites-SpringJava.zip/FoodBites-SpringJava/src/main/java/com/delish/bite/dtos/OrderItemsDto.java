package com.delish.bite.dtos;

import java.math.BigDecimal;

public class OrderItemsDto {

    private Long orderItemId;

    private String itemName;

    private int quantity;

    private BigDecimal price;

    private BigDecimal total;

    public OrderItemsDto() {
    }

    public OrderItemsDto(String itemName, int quantity, BigDecimal price, BigDecimal total) {
        this.itemName = itemName;
        this.quantity = quantity;
        this.price = price;
        this.total = total;
    }

    public OrderItemsDto(Long orderItemId, String itemName, int quantity, BigDecimal price, BigDecimal total) {
        this.orderItemId = orderItemId;
        this.itemName = itemName;
        this.quantity = quantity;
        this.price = price;
        this.total = total;
    }

    public Long getOrderItemId() {
        return orderItemId;
    }

    public void setOrderItemId(Long orderItemId) {
        this.orderItemId = orderItemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }
}
