package com.delish.bite.models;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.Positive;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Restaurant {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long restaurantId;

    @Column(nullable = false, unique = true)
    private String name;

    @Column(nullable = false, scale = 1)
    @DecimalMax("5")
    @Positive
    private Double rating;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "locationId", nullable = false)
    @JsonIgnore
    private Location location;

    @Column(nullable = false)
    private PriceIndicator priceIndicator;

    @Column()
    @Positive
    private Integer costForTwo; // Estimatated Cost, decimal values not required

    @OneToMany(mappedBy = "restaurant")
    private Set<Food> menu = new HashSet<>();

    public Long getRestaurantId() {
        return restaurantId;
    }

    public void setRestaurantId(Long restaurantId) {
        this.restaurantId = restaurantId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public PriceIndicator getPriceIndicator() {
        return priceIndicator;
    }

    public void setPriceIndicator(PriceIndicator priceIndicator) {
        this.priceIndicator = priceIndicator;
    }

    public Integer getCostForTwo() {
        return costForTwo;
    }

    public void setCostForTwo(Integer costForTwo) {
        this.costForTwo = costForTwo;
    }

    public Set<Food> getMenu() {
        return menu;
    }

    public void setMenu(Set<Food> menu) {
        this.menu = menu;
    }
}
