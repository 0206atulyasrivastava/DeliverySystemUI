package com.delish.bite.service;

import com.delish.bite.dtos.FoodDto;
import com.delish.bite.dtos.LocationDto;
import com.delish.bite.dtos.RestaurantDto;
import com.delish.bite.models.Food;
import com.delish.bite.models.Location;
import com.delish.bite.models.Restaurant;
import com.delish.bite.repositories.LocationRepo;
import com.delish.bite.repositories.MenuRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class LocationService {

    @Autowired
    LocationRepo locationRepo;

    @Autowired
    MenuRepo menuRepo;

    @Value("${peak.hours.time.hhmm.from}")
    private String peakHourTimeFrom;

    @Value("${peak.hours.time.hhmm.to}")
    private String getPeakHourTimeTo;

    @Value("${peak.hours.price.multiplier}")
    private Double priceMultiplier;

    public Set<LocationDto> getAllLocations() {
        List<Location> data = locationRepo.findAll();
        Set<LocationDto> result = new HashSet<>();

        data.forEach(e -> {
            result.add(new LocationDto(e.getLocationId(), e.getName()));
        });
        return result;
    }

    public Set<RestaurantDto> getAllRestaurantsInLocation(Long locationId) {
        Optional<Location> data = locationRepo.findById(locationId);
        if(data.isPresent()) {
            return getRestaurantListDto(data.get());
        }
        return null;
    }


    public List<FoodDto> getMenuByLocation(Long locationId) {
        Optional<Location> data = locationRepo.findById(locationId);
        if(data.isPresent()) {
            Set<Restaurant> restaurants = data.get().getRestaurantsInArea();
            return getFoodsByLoction(restaurants);
        }
        return null;
    }

    private Set<RestaurantDto> getRestaurantListDto(Location location) {
        Set<Restaurant> restaurants = location.getRestaurantsInArea();

        Set<RestaurantDto> restDtoSet = new HashSet<>();
        restaurants.forEach(e -> {
            restDtoSet.add(new RestaurantDto(e.getRestaurantId(), e.getName(), e.getRating(), e.getPriceIndicator()));
        });

        return restDtoSet;
    }

    private List<FoodDto> getFoodsByLoction(Set<Restaurant> restaurants) {
        List<FoodDto> result = new ArrayList<>();
        List<Food> foods = menuRepo.findByRestaurantIn(restaurants);

        Double surgeFactor = isPeakHour(peakHourTimeFrom, getPeakHourTimeTo) ? priceMultiplier : 1.0;

        //Converting to FoodDto
        for (Food food: foods ) {
            Restaurant r = food.getRestaurant();
            RestaurantDto rest = new RestaurantDto(r.getRestaurantId(), r.getName(), r.getRating(), r.getPriceIndicator());

            Location l = r.getLocation();
            LocationDto loc = new LocationDto(l.getLocationId(), l.getName());

            BigDecimal price = food.getPrice().multiply(new BigDecimal(surgeFactor));
            result.add(new FoodDto(food.getFoodId(), food.getName(), price, food.getFoodCategory(), food.isVagetarian(), rest, loc));
        }
        return  result;
    }

    private boolean isPeakHour(String from, String to) {
        SimpleDateFormat format = new SimpleDateFormat("hh:mm");
        Date now = new Date();
        String nowString = format.format(now);
        try {
            Date dfrom = format.parse(from);
            Date dNow = format.parse(nowString);
            Date dTo = format.parse(to);

            System.out.println(dfrom);
            System.out.println(dNow);
            System.out.println(dTo);

            return (dNow.compareTo(dfrom) > 0) && dTo.compareTo(dNow) > 0;
        } catch(Exception e) {
            System.out.println(e);
            return false;
        }
    }
}
