package com.delish.bite.repositories;

import com.delish.bite.models.OrderItems;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderItemRepo extends JpaRepository<OrderItems, Long> {
}
