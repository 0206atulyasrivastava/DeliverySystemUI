package com.delish.bite.repositories;

import com.delish.bite.models.DeliveryOrder;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DeliveryOrderRepo extends JpaRepository<DeliveryOrder, Long> {
}
