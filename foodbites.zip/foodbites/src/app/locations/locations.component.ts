import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-locations',
  templateUrl: './locations.component.html',
  styleUrls: ['./locations.component.scss']
})
export class LocationsComponent implements OnInit {

  location;

  locationsUrl = 'http://localhost:8080/api/location';

  constructor(private http: HttpClient, private router: Router) { }

  ngOnInit(): void {
    this.getLocations();
  }

  getLocations() {
    this.http.get(this.locationsUrl).subscribe(res => {
      this.location = res;
    });
  }
}
