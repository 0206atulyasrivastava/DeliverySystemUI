import { CartService } from './../cart.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.scss']
})
export class LocationComponent implements OnInit {

  urlPre = 'http://localhost:8080/api/location/';
  url: string;
  menu;
  price;
  rating;
  veg = false;

  ratings = ['', 1, 2, 3, 4, 4.5];
  locationId: number;

  constructor(private activatedRoute: ActivatedRoute, private http: HttpClient, private cartService: CartService) { }

  ngOnInit(): void {
    this.activatedRoute.queryParams.subscribe(params => {
      this.locationId = params['id'];
    });

    this.url = this.urlPre + this.locationId + '/menu';
    this.getLocationMenu();
  }


  getLocationMenu() {
    this.http.get(this.url).subscribe(res => {
      this.menu = res;
    });
  }

  addToCart(i) {
    this.cartService.addToCart(i.name, i.price, i.restaurant.restaurantName);
  }

  filterByRating(rating) {
    this.menu = this.menu.filter(e => e.restaurant.rating > rating);
  }

  filterVegetarian() {
    if (!this.veg) {
      this.getLocationMenu();
    }
    this.menu = this.menu.filter(e => e.vagetarian);
  }

  reset() {
    this.getLocationMenu();
  }

  priceLessThan(price) {
    this.menu = this.menu.filter(e => e.price < price);
  }

}
