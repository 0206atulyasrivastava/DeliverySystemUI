import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit {

  cartItems;
  quantity = [1, 2, 3, 4, 5];
  total: number;

  constructor(public cartService: CartService) { }

  ngOnInit(): void {
    console.log(this.cartService.getCart());

    this.cartItems = this.cartService.getCart();
    this.calculateTotal();
  }

  calculateTotal() {
    let sum = 0;
    this.cartItems.forEach(e => {
      sum = sum + (e.price * e.quantity);
    });
    this.total = sum;
  }

}
