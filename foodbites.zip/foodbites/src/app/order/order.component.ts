import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.scss']
})
export class OrderComponent implements OnInit {

  orderURL = 'http://localhost:8080/api/order';

  orderItems;
  total;

  error = false;
  oderSuccess = false;

  constructor(public cartService: CartService, private http: HttpClient, ) { }

  ngOnInit(): void {
    this.orderItems = this.cartService.getCart();
    this.calculateTotal();
  }
  calculateTotal() {
    let sum = 0;
    this.orderItems.forEach(e => {
      sum = sum + (e.price * e.quantity);
    });
    this.total = sum;
  }

  placeOrder() {
    let items = [];

    this.orderItems.forEach(e => {
      const itemTotal = e.price * e.quantity;
      const orderItem = { itemName: e.itemName, price: e.price, quantity: e.quantity, total: itemTotal }
      items.push(orderItem);
    });
    const data = { orderItems: items, totalAmount: this.total };

    this.http.post(this.orderURL, data).subscribe(
      (response) => {
        this.oderSuccess = true;
        this.cartService.emptyCart();
        console.log(response);
      },
      (error) => {
        this.error = true;
        this.cartService.emptyCart();
        console.log(error);
      }
    );

  }

}
