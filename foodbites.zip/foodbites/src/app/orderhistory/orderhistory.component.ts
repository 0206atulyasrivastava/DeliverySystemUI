import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-orderhistory',
  templateUrl: './orderhistory.component.html',
  styleUrls: ['./orderhistory.component.scss']
})
export class OrderhistoryComponent implements OnInit {

  orderhistoryURL = 'http://localhost:8080/api/order/';

  orderhistory;

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.getOrderHistory();
  }

  getOrderHistory() {
    this.http.get(this.orderhistoryURL).subscribe(res => {
      this.orderhistory = res;
    });
  }

}
