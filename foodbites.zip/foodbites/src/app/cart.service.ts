import { Injectable } from '@angular/core';

interface cart {
  itemName: string,
  price: number,
  quantity: number,
  restaurantName: string
}

@Injectable({
  providedIn: 'root'
})
export class CartService {

  private CART: cart[] = [];

  getCart() {
    return this.CART
  }

  addToCart(itemName: string, price: number, restaurantName: string) {
    let flag: boolean;

    for (let i = 0; i < this.CART.length; i++) {
      if (this.CART[i].itemName === itemName && this.CART[i].restaurantName === restaurantName) {
        this.CART[i].quantity += 1;
        flag = true;
        break;
      }
    }

    if (!flag) {
      const newItem: cart = { itemName: itemName, price: price, restaurantName: restaurantName, quantity: 1 };
      this.CART.push(newItem);
    }
  }

  removeItem(itemName: string, restaurantName: string) {
    for (let i = 0; i < this.CART.length; i++) {
      if (this.CART[i].itemName === itemName && this.CART[i].restaurantName === restaurantName) {
        this.CART.splice(i, 1);
        break;
      }
    }
  }

  emptyCart() {
    this.CART = [];
  }

  constructor() { }
}
