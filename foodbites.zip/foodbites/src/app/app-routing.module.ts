import { OrderhistoryComponent } from './orderhistory/orderhistory.component';
import { OrderComponent } from './order/order.component';
import { CartComponent } from './cart/cart.component';
import { LocationsComponent } from './locations/locations.component';
import { LocationComponent } from './location/location.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  { path: '', redirectTo: '/foodbites', pathMatch: 'full' },
  { path: 'foodbites', component: LocationsComponent },
  { path: 'foodbites/location', component: LocationComponent },
  { path: 'foodbites/mycart', component: CartComponent },
  { path: 'foodbites/order', component: OrderComponent },
  { path: 'foodbites/orderhistory', component: OrderhistoryComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
